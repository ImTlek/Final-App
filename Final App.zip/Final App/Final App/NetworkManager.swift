//
//  Networkmanager.swift
//  Lab6
//
//  Created by Tilek Bektursyn on 2.12.2022.
//

import Foundation

protocol NetworkManagerDelegate {
    func didUpdateHouses(with houses: [HouseResponseModel])
}

struct NetworkManager {
    
    var delegate: NetworkManagerDelegate?
    
    // Full version
    func getHouse() {
        let urlString = "https://wizard-world-api.herokuapp.com/Houses"
        guard let url = URL(string: urlString) else { return }
        let urlRequest = URLRequest(url: url)
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                print("Server Error: \(error.localizedDescription)")
            } else {
                guard let safeData = data else { return }
                decode(from: safeData)
            }
        }
        task.resume()
    }
    
    // Function to decode models from data
    private func decode(from data: Data) {
        do {
            let houses = try JSONDecoder().decode([HouseResponseModel].self, from: data)
            DispatchQueue.main.async {
                delegate?.didUpdateHouses(with: houses)
            }
        } catch {
            print("Parsing Error: \(error.localizedDescription)")
        }
    }
    
    // CompactVersion
    func compactGetHouse() {
        let urlString = "https://wizard-world-api.herokuapp.com/Houses"
        guard let url = URL(string: urlString) else { return }
        let urlRequest = URLRequest(url: url)
        URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                print("Server Error: \(error.localizedDescription)")
            } else {
                guard let data else { return }
                decode(from: data)
            }
        }.resume()
    }
}
