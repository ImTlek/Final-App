//
//  ViewController.swift
//  Lab6
//
//  Created by Tilek Bektursyn on 2.12.2022.
//

import UIKit

class ViewController: UIViewController, NetworkManagerDelegate {
    
    @IBOutlet private weak var houseName: UILabel!
    @IBOutlet private weak var houseImage: UIImageView!
    
    var networkManager = NetworkManager()
    
    var houses: [HouseResponseModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        networkManager.delegate = self
    }
    
    @IBAction private func rollButtonDidTap(_ sender: UIButton) {
        if houses.isEmpty {
            networkManager.getHouse()
        } else {
            guard let randomHouse = houses.randomElement() else { return }
            houseName.text = randomHouse.name
            houseImage.image = UIImage(named: randomHouse.name)
        }
    }
    
    func didUpdateHouses(with houses: [HouseResponseModel]) {
        self.houses = houses
        guard let randomHouse = houses.randomElement() else { return }
        houseName.text = randomHouse.name
        houseImage.image = UIImage(named: randomHouse.name)
    }
}
