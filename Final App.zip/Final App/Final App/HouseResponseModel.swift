//
//  HouseResponseModel.swift
//  Lab6
//
//  Created by Tilek Bektursyn on 2.12.2022.
//

import Foundation

struct HouseResponseModel: Decodable {
    let id: String
    let name: String
    let houseColours: String
    let heads: [HouseHead]
}

struct HouseHead: Decodable {
    let firstName: String
    let lastName: String
}
