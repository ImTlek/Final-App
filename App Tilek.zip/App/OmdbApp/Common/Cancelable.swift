//
//  Cancellable.swift
//  MVVM app
//
//  Created by Tlek Bektursyn
//

import Foundation

public protocol Cancellable {
    func cancel()
}
