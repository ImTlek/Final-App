//
//  MovieQuery.swift
//  
//
//  Created by Tlek Bektursyn
//

import Foundation

struct MovieQuery: Equatable
{
    let query: String
}
