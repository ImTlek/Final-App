//
//  UseCase.swift
//
//
//  Created by Tlek Bektursyn
//

import Foundation



public protocol UseCase
{
    @discardableResult
    func start() -> Cancellable?
}
