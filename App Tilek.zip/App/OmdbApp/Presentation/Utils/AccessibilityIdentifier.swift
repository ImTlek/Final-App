//
//  AccessibilityIdentifier.swift
//  ExampleMVVM
//
//  Created by Tlek Bektursyn
//

import Foundation

public struct AccessibilityIdentifier {
    static let movieDetailsView = "AccessibilityIdentifierMovieDetailsView"
    static let searchField = "AccessibilityIdentifierSearchMovies"
}
