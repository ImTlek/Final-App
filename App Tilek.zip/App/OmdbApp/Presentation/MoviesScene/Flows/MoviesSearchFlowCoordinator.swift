//
//  MoviesSearchFlowCoordinator.swift
//  
//
//  Created by Tlek Bektursyn
//

import Foundation
import UIKit

protocol MoviesSearchFlowCoordinatorDependencies
{
    func makeMoviesListViewController(actions: MoviesListViewModelActions) -> SearchController
    func makeMoviesDetailsViewController(movie: Movie) -> UIViewController
}

final class MoviesSearchFlowCoordinator {
    
    private weak var navigationController: UINavigationController?
    private let dependencies: MoviesSearchFlowCoordinatorDependencies

    private weak var moviesListVC: SearchController?
    private weak var moviesQueriesSuggestionsVC: UIViewController?

    init(navigationController: UINavigationController,
         dependencies: MoviesSearchFlowCoordinatorDependencies) {
        self.navigationController = navigationController
        self.dependencies = dependencies
    }
    
    func start()
    {
        let actions = MoviesListViewModelActions(showMovieDetails: showMovieDetails)

        let vc = dependencies.makeMoviesListViewController(actions: actions)

        navigationController?.pushViewController(vc, animated: false)
        moviesListVC = vc
    }

    private func showMovieDetails(movie: Movie) {
        let vc = dependencies.makeMoviesDetailsViewController(movie: movie)
        navigationController?.pushViewController(vc, animated: true)
    }
}
