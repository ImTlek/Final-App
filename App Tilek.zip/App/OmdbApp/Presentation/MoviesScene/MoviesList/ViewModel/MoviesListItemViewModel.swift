//
//  MovieViewModel.swift
//
//
//  Created by Tlek Bektursyn
//

import Foundation
import UIKit

struct MoviesListItemViewModel : Equatable {
    
    let poster : String
    let title : String
    let type : MovieType
    let year : String
    

}

extension MoviesListItemViewModel
{
    init(with model: Movie)
    {
        title = model.title!
        poster = model.poster!
        year = model.year!
        type = model.type!
    }
}
