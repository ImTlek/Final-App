//
//  MoviesRequestDTO+Mapping.swift
//  
//
//  Created by Tlek Bektursyn
//

import Foundation

struct MoviesRequestDTO: Encodable {
    let s: String
    let plot: String
}
