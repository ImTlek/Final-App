//
//  DefaultMoviesQueriesRepository.swift
//  ExampleMVVM
//
//  Created by Tlek Bektursyn.
//

import Foundation

final class DefaultMoviesQueriesRepository
{
    
    private let dataTransferService: DataTransferService
    
    
    init(dataTransferService: DataTransferService)
    {
        
        
        self.dataTransferService = dataTransferService
        
    }
}


extension DefaultMoviesQueriesRepository: MoviesQueriesRepository {
    
    func fetchRecentsQueries(maxCount: Int, completion: @escaping (Result<[MovieQuery], Error>) -> Void) {
         //return moviesQueriesPersistentStorage.fetchRecentsQueries(maxCount: maxCount, completion: completion)
    }
    
    func saveRecentQuery(query: MovieQuery, completion: @escaping (Result<MovieQuery, Error>) -> Void) {
         //moviesQueriesPersistentStorage.saveRecentQuery(query: query, completion: completion)
    }
}
